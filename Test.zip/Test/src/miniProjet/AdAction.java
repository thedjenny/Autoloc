package miniProjet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class AdAction implements ActionListener{
	AdLogin l;
	Advehicule v;
	public AdAction(AdLogin l) {
		this.l=l;
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b=(JButton) e.getSource();
		if(b==l.cnx) {
			String a=l.tuser.getText();
			String bb=new String(l.tpass.getPassword());
			if(l.tuser.getText().equals("") || bb.equals(""))
				JOptionPane.showMessageDialog(null, "Entrer le nom d'utilisateur et le mot de pass ");
			else {
				if(a.equals("ADMIN") && bb.equals("ADMIN")) {
					l.setVisible(false);
					v=new Advehicule();
					v.setVisible(true);
				}else
	 			  JOptionPane.showMessageDialog(null, " Le nom d'utilisateur ou le mot de pass sont incorrect ", "Erreur message", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		
	}

}
