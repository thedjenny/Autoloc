package miniProjet;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.Border;

public class Facture extends JFrame {
	JLabel numfact=new JLabel("Num�ro Facture");
	JLabel nom=new JLabel("Nom");
	JLabel prnm=new JLabel("pr�nom");
	JLabel nump=new JLabel("Num�ro du permis");
	JLabel mtcl=new JLabel("Matricule");
	JLabel mrq=new JLabel(" Marque: ");
	JLabel mdl=new JLabel(" Mod�le:");
	JLabel prix=new JLabel(" Prix unitaire: ");
	JLabel dated=new JLabel("allouer de:");
	JLabel datef=new JLabel("jusqu'a:");
	JLabel prixt=new JLabel("Prix Total");
	JButton b=new JButton("acceuil");
	JButton b1=new JButton("Imprimer");
	JPanel p=new JPanel();
	JPanel p1=new JPanel();
	JPanel p2 =new JPanel();
	String bb;
	public Facture(String bb) {
		this.bb=bb;
		b.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/home.jpg.png"));
		b1.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/imprimer.jpg.png"));
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Impression en cours ");
			}
		});
		b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Home h=new Home(bb);
				setVisible(false);
				h.setVisible(true);
			}
		});
		setTitle("Facture");
		setSize(400, 400);
		p1.setLayout(new GridLayout(11, 1));
		p1.setBorder(BorderFactory.createTitledBorder("Facture"));
		p.setLayout(new BorderLayout());
		p2.setBackground(Color.gray);
		p1.add(numfact);
		p1.add(nom);
		p1.add(prnm);
		p1.add(nump);
		p1.add(mtcl);
		p1.add(mrq);
		p1.add(mdl);
		p1.add(prix);
		p1.add(dated);
		p1.add(datef);
		p1.add(prixt);
		p2.add(b);
		p2.add(b1);
		p.add(p1,BorderLayout.CENTER);
		p.add(p2, BorderLayout.SOUTH);
		getContentPane().add(p);
		setLocationRelativeTo(null);
		
	}
	
	

}
