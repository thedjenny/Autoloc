package miniProjet;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class autofind {
	cnx connect;
	ResultSet rs;
	auto t;
	ArrayList<auto>ar=new ArrayList<>();
	
	public ArrayList<auto> lect(String type){
        try {
            connect=new cnx();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        String sql="Select * From vehicule where typ='"+type+"'";
		try {
			rs=connect.stat.executeQuery(sql);
			System.out.println(sql);
			while(rs.next()) {
				t=new auto(Integer.parseInt(rs.getObject(1).toString()), rs.getObject(3).toString(),rs.getObject(4).toString(),rs.getObject(6).toString(),Integer.parseInt(rs.getObject(5).toString()));
				ar.add(t);
			}
			
			System.out.println( "connection ");
			rs.close();
			connect.getCnx().close();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ar ;
		}

}
