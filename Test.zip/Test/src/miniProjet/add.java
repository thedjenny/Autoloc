package miniProjet;

import java.sql.ResultSet;
import java.sql.SQLException;

public class add {
	cnx connect;
	int rsl;
	public boolean ajouter(String name,String nom,String pr�nom ,String numt,String nump,String pass){
		try {
			connect=new cnx();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		boolean b=false;
		int i ;
		try {
		String sql="INSERT INTO client(userr, nom, prnm, numt, nump, pass) VALUES ('"+name+"','"+nom+"' ,'"+pr�nom+"' ,'"+numt+"' ,'"+nump+"' ,'"+pass+"')";
		rsl=connect.stat.executeUpdate(sql);
		System.out.println(rsl);
			if(rsl==1){
			b=true;
			System.out.println( " cbn "+b);
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(b);
		
		return b;}
	public boolean ajouterF(String user,int mat,int total ,String datd,String datf){
		try {
			connect=new cnx();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		boolean b=false;
		int i ;
		try {
		String sql="INSERT INTO facture( datedeb, datefin, userr, mat, total)	VALUES ('"+datd+"','"+datf+"','"+user+"','"+mat+"','"+total+"')";
		rsl=connect.stat.executeUpdate(sql);
		System.out.println(rsl);
			if(rsl==1){
			b=true;
			System.out.println( " cbn "+b);
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(b);
		
		return b;}
	public boolean ajouOff(String type,int mat,String mdl,String mrq,int prx,String userr) {
		try {
			connect=new cnx();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		boolean b=false;
		int i ;
		try {
		String sql="INSERT INTO offre( typ, mat, mdl, mrq, prx, userr,etat) VALUES ('"+type+"','"+mat+"','"+mdl+"','"+mrq+"','"+prx+"','"+userr+"','n/a')";
		rsl=connect.stat.executeUpdate(sql);
		System.out.println(rsl);
			if(rsl==1){
			b=true;
			System.out.println( " cbn "+b);
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(b);
		
		return b;
	}
	public boolean ajouV(String type,int mat,String mdl,String mrq,int prx) {
		try {
			connect=new cnx();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		boolean b=false;
		int i ;
		try {
		String sql="INSERT INTO vehicule(mat, typ, modl, marq, prix, etat) VALUES ('"+mat+"','"+type+"','"+mdl+"','"+mrq+"','"+prx+"','disponible')";
		rsl=connect.stat.executeUpdate(sql);
		System.out.println(rsl);
			if(rsl==1){
			b=true;
			System.out.println( " cbn "+b);
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(b);
		
		return b;
	}
	public boolean supp(int mat) {
		try {
			connect=new cnx();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		boolean b=false;
		int i ;
		try {
		String sql="DELETE FROM vehicule WHERE mat='"+mat+"'";
		rsl=connect.stat.executeUpdate(sql);
		System.out.println(rsl);
			if(rsl==1){
			b=true;
			System.out.println( " cbn "+b);
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(b);
		
		return b;
	}
	
		
}
