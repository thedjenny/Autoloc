package miniProjet;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class find {
	cnx connect;
	ResultSet rs;
	Client c=new Client();
	ArrayList<off>ar=new ArrayList<>();
	off t;
	public boolean lecture(String name) throws SQLException {
		 try {
            connect=new cnx();
        } catch (SQLException e) {
            e.printStackTrace();
        }
		boolean b=false;
		String sql="Select * From client where userr='"+name+"'";
		try {
			rs=connect.stat.executeQuery(sql);
			System.out.println(sql);
			if(rs.next()){
			c.name=rs.getString("userr");
			c.nom=rs.getString("nom");
			c.pr�nom=rs.getString("prnm");
			c.nump=rs.getString("nump");
			c.numt=rs.getString("numt");
			c.pass=rs.getString("pass");
			b=true;
			System.out.println( "connection "+b);
			rs.close();
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b ;
		}

	public boolean lecture(String name,String pass){
		 try {
            connect=new cnx();
        } catch (SQLException e) {
            e.printStackTrace();
        }

		boolean b=false;
		String sql="Select * From client where userr='"+name+"' and pass='"+pass+"'";
		try {
			rs=connect.stat.executeQuery(sql);

			if(rs.next()){

			b=true;
			System.out.println( "connection "+b);
			//System.out.println(c.name+" "+c.nom);
			rs.close();
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}
	public int numfact(){
        try {
            connect=new cnx();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        int i = 0;
		String sql="Select max(numfact) from facture";
		try {
			rs=connect.stat.executeQuery(sql);

			if(rs.next()){
				i=rs.getInt("max");
			System.out.println( "connection ");
			//System.out.println(c.name+" "+c.nom);
			rs.close();
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	public ArrayList<off> Foff(){
		 try {
            connect=new cnx();
        } catch (SQLException e) {
            e.printStackTrace();
        }
		String sql="Select * From offre" ;
		try {
			rs=connect.stat.executeQuery(sql);
			System.out.println(sql);
			while(rs.next()) {
				t=new off(Integer.parseInt(rs.getObject(1).toString()),Integer.parseInt(rs.getObject(6).toString()) ,Integer.parseInt(rs.getObject(3).toString()) ,rs.getObject(2).toString(),rs.getObject(4).toString() ,rs.getObject(5).toString() ,rs.getObject(7).toString() ,rs.getObject(8).toString());
				ar.add(t);
			}
			
			System.out.println( "connection ");
			rs.close();
			connect.getCnx().close();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ar ;
		}
	
}