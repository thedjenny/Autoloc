package miniProjet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Action implements ActionListener{
	Login l;
	Inscription i;
	Home h;
	find f=new find();
	
	public Action(Login l) {
		this.l=l;
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b=(JButton) e.getSource();
		if(b==l.inscri) {
			l.setVisible(false);
			i=new Inscription();
			i.setVisible(true);
		}
		if(b==l.cnx) {
			String a=l.tuser.getText();
			String bb=new String(l.tpass.getPassword());
			if(l.tuser.getText().equals("") || bb.equals(""))
				JOptionPane.showMessageDialog(null, "Entrer le nom d'utilisateur et le mot de pass ");
			else {
				if(f.lecture(a, bb)) {
					l.setVisible(false);
					h=new Home(a);
					h.setVisible(true);
				}else
	 			  JOptionPane.showMessageDialog(null, " Le nom d'utilisateur ou le mot de pass sont incorrect ", "Erreur message", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		
	}

}
