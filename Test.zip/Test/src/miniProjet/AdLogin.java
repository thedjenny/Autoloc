package miniProjet;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AdLogin extends JFrame {
	JLabel user=new JLabel("Nom d'utilisateur: "),
			pass=new JLabel("Mot de pass: "),
			msg=new JLabel("Bienvenue ADMIN ");
	
	JTextField tuser=new JTextField(20);
	JPasswordField tpass=new JPasswordField(20);
			
	
	JButton cnx=new JButton("Connexion");
			
	
	JPanel p=new JPanel(),
			p1=new JPanel(),
			p2=new JPanel(),
			p3=new JPanel(),
			p4=new JPanel(),
			p5=new JPanel();
	
	public AdLogin() {
		cnx.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/login.jpg.png"));
		cnx.setBackground(Color.WHITE);
		AdAction a=new AdAction(this);
		cnx.addActionListener(a);
		setTitle("Authetification");
		setSize(400, 200);
		p1.add(user);
		p2.add(pass);
		p1.add(tuser);
		p2.add(tpass);
		p3.add(cnx);
		
		p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
		p.setBorder(BorderFactory.createTitledBorder("Login"));
		p.add(p1);
		p.add(p2);
		p.add(p3);
		
		p4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		msg.setFont(new Font(Font.DIALOG,Font.BOLD,25));
		p4.add(msg);
		
		p5.setLayout(new BoxLayout(p5, BoxLayout.Y_AXIS));
		p5.add(p4);
		p5.add(p);
		setVisible(true);
		getContentPane().add(p5);
		setLocationRelativeTo(null);
		
	}
	public static void main(String[] args) {
		new AdLogin();
	}

}
