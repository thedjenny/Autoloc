package miniProjet;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.*;

public class Home extends JFrame {
	String b;
	JButton b1=new JButton("V�hicule"),
			b2=new JButton("Offre"),
			b3=new JButton("Info"),
			b4=new JButton("Exit");
	JPanel p=new JPanel(),
			p1=new JPanel(),pp=new JPanel(),
			p2=new JPanel();
	JLabel msg=new JLabel("Bienvenue");
	public Home(String b) {
		this.b=b;
		Action3 a=new Action3(this);
		b1.addActionListener(a);
		b2.addActionListener(a);
		b3.addActionListener(a);
		b4.addActionListener(a);
		b1.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/key.jpg.png"));
		b2.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/offre.jpg.png"));
		b3.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/info.jpg.png"));
		b4.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/exit.001.jpg.png"));
		setTitle("Home");
		setSize(300, 400);
		p1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		pp.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		msg.setFont(new Font(Font.DIALOG,Font.BOLD,25));
		msg.setText("Bienvenue "+b);
		p.setLayout(new GridLayout(4, 1,20,20));
		p.setPreferredSize(new Dimension(150, 250));
		//p.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		p.add(b1);
		p.add(b2);
		p.add(b3);
		p.add(b4);
		pp.add(p);
		p1.add(msg);
		p2.setLayout(new BoxLayout(p2, BoxLayout.Y_AXIS));
		p2.add(p1);
		p2.add(pp);
		getContentPane().add(p2);
		setLocationRelativeTo(null);
		
	}

}
