package miniProjet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Action2 implements ActionListener{
	Inscription i ;
	Home h;
	add ad=new add();
	find f=new find();
	
	
	public Action2(Inscription i) {
		this.i=i;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b=(JButton) e.getSource();
		if(b==i.b2)
			System.exit(0);
		if(b==i.b1) {
			String a=i.t1.getText();
			String bb=i.t2.getText();
			String c=i.t3.getText();
			String d=i.t4.getText();
			String ee=i.t5.getText();
			String pass=new String(i.pas.getPassword());
			String pass2=new String(i.pas2.getPassword());
			if(a.equals("") ||bb.equals("") ||c.equals("") ||ee.equals("") ||pass.equals("") || pass2.equals("")) 
				JOptionPane.showMessageDialog(null, "veuillez remplir tous les champs");
			else {
				if(pass.equals(pass2)) {
					try {
						if(f.lecture(ee))
							JOptionPane.showMessageDialog(null, "Ce nom d'utilisateur existe d�ja");
						else {
						ad.ajouter(ee, a, bb,c , d, pass);
						JOptionPane.showMessageDialog(null, "Vous avez bien inscrit");
						i.setVisible(false);
						h=new Home(ee);
						h.setVisible(true);
						}
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}else
					JOptionPane.showMessageDialog(null, "Confirmer votre mot de passe");
			}
				
		}
		
	}

}
