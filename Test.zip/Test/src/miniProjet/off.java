package miniProjet;

public class off {
	int num,prx,mat;
	String typ,mdl,mrq,user,etat;
	public off(int num, int prx, int mat, String typ, String mdl, String mrq, String user, String etat) {
		this.num = num;
		this.prx = prx;
		this.mat = mat;
		this.typ = typ;
		this.mdl = mdl;
		this.mrq = mrq;
		this.user = user;
		this.etat = etat;
	}
	
	

}
