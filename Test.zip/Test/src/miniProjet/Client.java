package miniProjet;

public class Client {
	String name;
	String nom;
	String pr�nom;
	String numt;
	String nump;
	String pass;

}
