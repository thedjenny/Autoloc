package miniProjet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class AdActionv implements ActionListener , ItemListener {
	addve of;
	Advehicule v;
	String type;
	add ad=new add();
	public AdActionv(addve of) {
		this.of=of;
	}

	public void itemStateChanged(ItemEvent e) {
		type=(String) of.c.getSelectedItem();
		
	}

	public void actionPerformed(ActionEvent e) {
		JButton bb=(JButton) e.getSource();
		if(bb==of.bv) {
			String mat=of.tmat.getText();
			String mdl=of.tmdl.getText();
			String mrq=of.tmrq.getText();
			String prx=of.tprx.getText();
			if(mdl.equals("") || mrq.equals("") || mat.equals("") || prx.equals(""))
				JOptionPane.showMessageDialog(null, "Veuiller remplir tout les champs ");
			else {
				ad.ajouV(type, Integer.parseInt(mat), mdl, mrq,Integer.parseInt(prx));
				JOptionPane.showMessageDialog(null, "Vous avez bien ajouter ce v�hicule");
				of.tmat.setText("");
				of.tmdl.setText("");
				of.tmrq.setText("");
				of.tprx.setText("");
			}
			
		}
		if(bb==of.rtr) {
			    of.setVisible(false);
				v=new Advehicule();
				v.setVisible(true);
		}
		
	}

}
