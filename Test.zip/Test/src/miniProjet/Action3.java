package miniProjet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class Action3 implements ActionListener {
	Home h;
	Info i;
	V�hicule v;
	Offre o;
	public Action3(Home h) {
		this.h=h;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b=(JButton) e.getSource();
		if(b==h.b4)
			System.exit(0);
		if(b==h.b3) {
			h.setVisible(false);
			i=new Info(h.b);
			i.setVisible(true);
		}
		if(b==h.b1){
			h.setVisible(false);
			v=new V�hicule(h.b);
			v.setVisible(true);
		}
		if(b==h.b2) {
			h.setVisible(false);
			o=new Offre(h.b);
			o.setVisible(true);
		}
		
	}

}
