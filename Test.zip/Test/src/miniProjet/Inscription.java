package miniProjet;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.*;

public class Inscription extends JFrame {
	JPanel p=new JPanel(),
			p1=new JPanel(),
			p2=new JPanel(),
			p3=new JPanel();
	JLabel nom=new JLabel("Nom: "),
			prnm=new JLabel("Pr�nom: "),
			user=new JLabel("Nom d'utilisateur: "),
			num=new JLabel("Num�ro du t�l�phone: "),
			permis=new JLabel("Num�ro du permis: "),
			pass=new JLabel("Mot de passe: "),
			pass2=new JLabel("Confirmer mot de passe: ");
	JTextField t1=new JTextField(15),
			t2=new JTextField(15),
			t3=new JTextField(15),
			t4=new JTextField(15),
			t5=new JTextField(15);
	JPasswordField pas=new JPasswordField(),
			pas2=new JPasswordField();
	JButton b1=new JButton("Confirmer"),
			b2=new JButton("Annuler");
public Inscription() {
	Action2 a=new Action2(this);
	b1.addActionListener(a);
	b2.addActionListener(a);
	b1.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/valider.jpg.png"));
	b2.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/exit.000.jpg.png"));
	
	setTitle("Inscription");
	setSize(400, 300);
	
	p1.setLayout(new GridLayout(7, 1));
	p1.add(nom);
	p1.add(prnm);
	p1.add(num);
	p1.add(permis);
	p1.add(user);
	p1.add(pass);
	p1.add(pass2);
	
	p2.setLayout(new GridLayout(7, 1));
	p2.add(t1);
	p2.add(t2);
	p2.add(t3);
	p2.add(t4);
	p2.add(t5);
	p2.add(pas);
	p2.add(pas2);
	
	p3.add(b1);
	p3.add(b2);
	
	p.setBorder(BorderFactory.createTitledBorder("Formulaire"));
	p.setLayout(new BorderLayout());
	p.add(p1,BorderLayout.WEST);
	p.add(p2,BorderLayout.CENTER);
	p.add(p3, BorderLayout.SOUTH);
	
	getContentPane().add(p);
	setLocationRelativeTo(null);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	
}


}
