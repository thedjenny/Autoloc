package miniProjet;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.*;

public class V�hicule extends JFrame {
	JPanel p=new JPanel();
	JPanel p1=new JPanel();
	JPanel p2=new JPanel();
	JPanel p3=new JPanel();
	JPanel p4=new JPanel();
	JPanel p5=new JPanel();
	JPanel p6=new JPanel();
	JPanel p7=new JPanel();
	JPanel p8=new JPanel();
	JPanel pa=new JPanel();
	
	
	JButton louer=new JButton("Allouer");
	JButton retour=new JButton("Retour");
	JButton voiture=new JButton("Voiture");
	JButton moto=new JButton("Moto");
	JButton bus=new JButton("Bus");
	JButton camion=new JButton("Camion");
	JButton nxt=new JButton("");
	JButton bck=new JButton("");
	
	JLabel mtcl=new JLabel("Matricule");
	JLabel mrq=new JLabel("          Marque: ");
	JLabel mdl=new JLabel("          Mod�le:");
	JLabel prix=new JLabel("          Prix: ");
	JLabel etat=new JLabel("          Etat: ");
	JLabel chx=new JLabel("             **** Choisissez un V�hicule :D **** ");
	ImageIcon i=new ImageIcon("C:/Users/AMINE/Desktop/images.png");
	ImageIcon i1=new ImageIcon("C:/Users/AMINE/Desktop/images2.jpg");
	ImageIcon i2=new ImageIcon("C:/Users/AMINE/Desktop/images1.jpg");
	ImageIcon i3=new ImageIcon("C:/Users/AMINE/Desktop/telechargement.jpg");
	ImageIcon i4=new ImageIcon("C:/Users/AMINE/Desktop/LOGO-LOCATION.jpg");
	JLabel ja=new JLabel(i4);
	JLabel j=new JLabel(i);
	String b;
	JPanel conteneur=new JPanel();
	CardLayout card=new CardLayout();
	String[] lcard= {"1","2"};
	
	//fenetre  date:
		JFrame f2=new JFrame("Vehicule");
		JPanel pf=new JPanel(),
				pf1=new JPanel(),
				pf2=new JPanel();
		JLabel lf=new JLabel("Combien de jour voulez vous l'allouer:   ");
		JLabel lf1=new JLabel(""+1);
		JButton plus=new JButton("+"),
				moin=new JButton("-"),
				alr=new JButton("Allouer"),
				rtr=new JButton("Retour");

	

	public V�hicule(String b) {
		louer.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/valider.jpg.png"));
		retour.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/retour.jpg.png"));
		nxt.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/nxt.png"));
		bck.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/bck.png"));
		alr.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/valider.jpg.png"));
		rtr.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/retour.jpg.png"));
		ActionV v=new ActionV(this);
		louer.addActionListener(v);
		retour.addActionListener(v);
		voiture.addActionListener(v);
		moto.addActionListener(v);
		bus.addActionListener(v);
		camion.addActionListener(v);
		nxt.addActionListener(v);
		bck.addActionListener(v);
		plus.addActionListener(v);
		moin.addActionListener(v);
		alr.addActionListener(v);
		rtr.addActionListener(v);
		this.b=b;
		setTitle("v�hicule");
		setSize(400, 300);
		
		//fenetre date
		f2.setSize(400, 150);
		pf.setLayout(new BorderLayout());
		pf1.setBorder(BorderFactory.createTitledBorder("Jour"));
		pf1.add(lf);
		pf1.add(moin);
		pf1.add(lf1);
		pf1.add(plus);
		pf2.add(alr);
		pf2.add(rtr);
		pf.add(pf1,BorderLayout.CENTER);
		pf.add(pf2,BorderLayout.SOUTH);
		f2.getContentPane().add(pf);
		f2.setLocationRelativeTo(null);
		f2.setVisible(false);
		conteneur.setBorder(BorderFactory.createLineBorder(Color.gray));
		p1.setBorder(BorderFactory.createLineBorder(Color.gray));
		p4.setBorder(BorderFactory.createLineBorder(Color.gray));
		p3.setBorder(BorderFactory.createLineBorder(Color.gray));
		p3.add(louer);
		p3.add(retour);
		p2.setLayout(new GridLayout(4,1,50,20));
		p2.setPreferredSize(new Dimension(100, 200));
		p2.add(voiture);
		p2.add(moto);
		p2.add(bus);
		p2.add(camion);
		p4.add(p2);
		p5.add(bck);
		p5.add(nxt);
		p7.setLayout(new GridLayout(3, 1));
		p7.add(mtcl);
		p7.add(mrq);
		p7.add(mdl);
		p7.add(etat);
		p7.add(prix);
		p8.add(j);
		p6.setLayout(new GridLayout(2, 1));
		p6.add(p8);
		p6.add(p7);
		p1.setLayout(new BorderLayout());
		p1.add(p6,BorderLayout.CENTER);
		p1.add(p5,BorderLayout.SOUTH);
		pa.setLayout(new BorderLayout());
		pa.add(ja,BorderLayout.CENTER);
		pa.add(chx, BorderLayout.SOUTH);
		conteneur.setLayout(card);
		conteneur.add(pa,lcard[0]);
		conteneur.add(p1,lcard[1]);
		p.setLayout(new BorderLayout());
		p.add(conteneur,BorderLayout.CENTER);
		p.add(p4, BorderLayout.WEST);
		p.add(p3, BorderLayout.SOUTH);
		getContentPane().add(p);
		setLocationRelativeTo(null);
		setVisible(false);
	}
	
}
