package miniProjet;

import java.text.DateFormat;
import java.util.Date;

public class auto {
	int matricule;
	String modele,marque,etat;
	int prix;
	
	public auto(int matricule, String modele, String marque, String etat, int prix) {
		this.matricule = matricule;
		this.modele = modele;
		this.marque = marque;
		this.etat = etat;
		this.prix = prix;
	}
	
}
