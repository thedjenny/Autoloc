package miniProjet;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class addve extends JFrame {
	JComboBox<String>c=new JComboBox<>();
	JLabel typ=new JLabel("Type:");
	JLabel mat=new JLabel("Matricule:");
	JLabel mdl=new JLabel("Model:");
	JLabel mrq=new JLabel("Marque:");
	JLabel prx=new JLabel("Prix(DA):");
	JTextField tmat=new JTextField(15);
	JTextField tmdl=new JTextField(15);
	JTextField tmrq=new JTextField(15);
	JTextField tprx=new JTextField(15);
	JPanel p=new JPanel();
	JPanel p1=new JPanel();
	JPanel p2=new JPanel();
	JButton bv=new JButton("Ajouter");
	JButton rtr=new JButton("Retour");
	public addve() {
		bv.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/add.000.jpg.png"));
		rtr.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/retour.jpg.png"));
		bv.setBackground(Color.WHITE);
		rtr.setBackground(Color.WHITE);
		AdActionv a=new AdActionv(this);
		bv.addActionListener(a);
		rtr.addActionListener(a);
		c.addItemListener(a);
		setTitle("Offre");
		setSize(400, 300);
		p.setLayout(new BorderLayout());
		p1.setBorder(BorderFactory.createTitledBorder("Ajouter v�hicule: "));
		p1.setLayout(new GridLayout(5, 2,00,15));
		c.addItem("voiture");
		c.addItem("camion");
		c.addItem("bus");
		c.addItem("moto");
		p1.add(typ);
		p1.add(c);
		p1.add(mat);
		p1.add(tmat);
		p1.add(mdl);
		p1.add(tmdl);
		p1.add(mrq);
		p1.add(tmrq);
		p1.add(prx);
		p1.add(tprx);
		p2.setBackground(Color.GRAY);
		p2.add(bv);
		p2.add(rtr);
		p.add(p1,BorderLayout.CENTER);
		p.add(p2, BorderLayout.SOUTH);
		setContentPane(p);
		setLocationRelativeTo(null);
		
	}
	
}
