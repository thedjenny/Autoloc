package miniProjet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;



public class AdVaction implements ActionListener {
	Advehicule v;
	ArrayList<auto>to;
	auto t;
	addve adv;
	int indic;
	int i=1;
	int indi=1;
	autofind f=new autofind();
	Modify md=new Modify();
	add ad=new add();
	find ff=new find();
	ArrayList<off> ar;
	off of;
	public AdVaction(Advehicule v) {
		this.v=v;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b=(JButton) e.getSource();
		if(b==v.retour) {
			System.exit(0);
		}
		if(b==v.camion) {
			v.card.show(v.conteneur, v.lcard[1]);
			indic=1;
			to=f.lect("camion");
			to.clear();
			to=f.lect("camion");
			v.j.setIcon(v.i1);
			t=to.get(0);
			v.mtcl.setText("         Matricule:  "+t.matricule);
			v.mdl.setText("         Mod�le: "+t.modele);
			v.mrq.setText("         Marque:  "+t.marque);
			v.etat.setText("         Etat:  "+t.etat);
			v.prix.setText("         Prix:  "+t.prix+" DA");
		}
		if(b==v.bus) {
			v.card.show(v.conteneur, v.lcard[1]);
			indic=1;
			to=f.lect("bus");
			to.clear();
			to=f.lect("bus");
			v.j.setIcon(v.i3);
			t=to.get(0);
			v.mtcl.setText("         Matricule:  "+t.matricule);
			v.mdl.setText("         Mod�le: "+t.modele);
			v.mrq.setText("         Marque:  "+t.marque);
			v.etat.setText("         Etat:  "+t.etat);
			v.prix.setText("         Prix:  "+t.prix+" DA");
		}
		if(b==v.voiture) {
			v.card.show(v.conteneur, v.lcard[1]);
			indic=1;
			to=f.lect("voiture");
			to.clear();
			to=f.lect("voiture");
			v.j.setIcon(v.i);
			t=to.get(0);
			v.mtcl.setText("         Matricule:  "+t.matricule);
			v.mdl.setText("         Mod�le: "+t.modele);
			v.mrq.setText("         Marque:  "+t.marque);
			v.etat.setText("         Etat:  "+t.etat);
			v.prix.setText("         Prix:  "+t.prix+" DA");
		}
		if(b==v.moto) {
			v.card.show(v.conteneur, v.lcard[1]);
			indic=1;
			to=f.lect("moto");
			to.clear();
			to=f.lect("moto");
			v.j.setIcon(v.i2);
			t=to.get(0);
			v.mtcl.setText("         Matricule:  "+t.matricule);
			v.mdl.setText("         Mod�le: "+t.modele);
			v.mrq.setText("         Marque:  "+t.marque);
			v.etat.setText("         Etat:  "+t.etat);
			v.prix.setText("         Prix:  "+t.prix+" DA");
		}
		if(b==v.nxt) {
			if(indic<to.size()) {
				t=to.get(indic);
				v.mtcl.setText("         Matricule:  "+t.matricule);
				v.mdl.setText("         Mod�le: "+t.modele);
				v.mrq.setText("         Marque:  "+t.marque);
				v.etat.setText("         Etat:  "+t.etat);
				v.prix.setText("         Prix:  "+t.prix+" DA");
				indic++;
				}
				else
					JOptionPane.showMessageDialog(null, "C'est le dernier v�hicule");
		}
		if(b==v.bck) {
			if(indic>1) {
				t=to.get(indic-2);
				v.mtcl.setText("         Matricule:  "+t.matricule);
				v.mdl.setText("         Mod�le: "+t.modele);
				v.mrq.setText("         Marque:  "+t.marque);
				v.etat.setText("         Etat:  "+t.etat);
				v.prix.setText("         Prix:  "+t.prix+" DA");
				indic--; 
				
				}else
					JOptionPane.showMessageDialog(null, "C'est le dernier v�hicule");
		}
		if(b==v.louer) {
			if(v.mtcl.getText().equals("Matricule")) 
				JOptionPane.showMessageDialog(null, "Choisissez un v�hicule");
			else {
				v.f1.setVisible(true);
				v.setVisible(false);
				v.maaat.setText(""+t.matricule);
				v.tmat.setText(t.etat);
				v.tmdl.setText(t.modele);
				v.tmrq.setText(t.marque);
				v.tprx.setText(""+t.prix);
			}
				
			
			System.out.println(v.mtcl.getText());
		}
		if(b==v.supp) {
			if(v.mtcl.getText().equals("Matricule")) 
				JOptionPane.showMessageDialog(null, "Choisissez un v�hicule");
			else {
				JOptionPane op=new JOptionPane();
				int opt=op.showConfirmDialog(null, "Voulez vous supprimer ce v�hicule ?","Supprimer",JOptionPane.YES_NO_OPTION);
				if(opt==JOptionPane.YES_OPTION) {
					ad.supp(t.matricule);
					JOptionPane.showMessageDialog(null, "V�hicule supprimer");
					v.setVisible(false);
					v=new Advehicule();
					v.setVisible(true);
				}
				
			}
			
		}
		if(b==v.ajt) {
			v.setVisible(false);
			adv=new addve();
			adv.setVisible(true);
		}
		if(b==v.off) {
			
			v.f2.setVisible(true);
			ar=ff.Foff();
			of=ar.get(0);
			v.fnumfact.setText("     num�ro d'offre: "+of.num);
			v.fetat.setText("         "+of.etat);
			v.fnom.setText("       Type: "+of.typ);
			v.fmtcl.setText("       Matricule: "+of.mat);
			v.fmrq.setText("       Marque: "+of.mrq);
			v.fmdl.setText("       Model: "+of.mdl);
			v.fprix.setText("       Prix: "+of.prx);
			v.fprnm.setText("       User: "+of.user);
			
			
		}
		if(b==v.bv) {
			if(md.mdfV(""+t.matricule, v.tmdl.getText(), v.tmrq.getText(), v.tprx.getText(), v.tmat.getText())) {
				JOptionPane.showMessageDialog(null, "V�hicule modifier ");
				v.f1.setVisible(false);
				v=new Advehicule();
				v.setVisible(true);
			}
		}
		if(b==v.rtr) {
			v.f1.setVisible(false);
			v.setVisible(true);
		}
		if(b==v.f2b3) {
			if(indi<ar.size()) {
				of=ar.get(indi);
				v.fnumfact.setText("     num�ro d'offre: "+of.num);
				v.fetat.setText("         "+of.etat);
				v.fnom.setText("       Type: "+of.typ);
				v.fmtcl.setText("       Matricule: "+of.mat);
				v.fmrq.setText("       Marque: "+of.mrq);
				v.fmdl.setText("       Model: "+of.mdl);
				v.fprix.setText("       Prix: "+of.prx);
				v.fprnm.setText("       User: "+of.user);
				indi++;
				}
				else
					JOptionPane.showMessageDialog(null, "C'est la derniere Offre");
			
		}
		if(b==v.f2b4) {
			if(indi>1) {
				of=ar.get(indi-2);
				v.fnumfact.setText("     num�ro d'offre: "+of.num);
				v.fetat.setText("         "+of.etat);
				v.fnom.setText("       Type: "+of.typ);
				v.fmtcl.setText("       Matricule: "+of.mat);
				v.fmrq.setText("       Marque: "+of.mrq);
				v.fmdl.setText("       Model: "+of.mdl);
				v.fprix.setText("       Prix: "+of.prx);
				v.fprnm.setText("       User: "+of.user);
				indi--; 
				
				}else
					JOptionPane.showMessageDialog(null, "C'est la Premiere Offre");
			
		}
		if(b==v.f2b2) {
			v.f2.setVisible(false);
		}
		if(b==v.f2b) {
			
			if(of.etat.equals("ACCEPTER") || of.etat.equals("REFUSER"))
				JOptionPane.showMessageDialog(null, "Cet Offre est accepter ou refuser");
			else {
				of.etat="ACCEPTER";
			v.fetat.setText("         ACCEPTER");
			md.mdfO(of.num, "ACCEPTER");
			ad.ajouV(of.typ, of.mat, of.mdl, of.mrq, of.prx);
			}
			
		}
		if(b==v.f2b1) {
			
			if(of.etat.equals("REFUSER") || of.etat.equals("ACCEPTER"))
				JOptionPane.showMessageDialog(null, "Cet Offre est accepter ou refuser");
			else {
			of.etat="REFUSER";
			v.fetat.setText("         REFUSER");
			md.mdfO(of.num, "REFUSER");
			}
			
		}
		
		
		
	}

}
