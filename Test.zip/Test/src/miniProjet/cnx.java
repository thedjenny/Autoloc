package miniProjet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;

public class cnx {
	private Connection conx;
	Statement stat;
/*
	private String user="postgres";
	private String password="admin";
	private String driver="org.postgresql.Driver";
	private String url="jdbc:postgresql://localhost:5432/projet";
	*/

	String url="jdbc:mysql://localhost:3306/projet";
	String user="root" ;
	String password="" ;

	public cnx() throws SQLException {
		connect();
	}
	
	private void connect() throws SQLException {

			//DriverManager.registerDriver((java.sql.Driver)Class.forName(driver).newInstance());
			setCnx(DriverManager.getConnection(url,user, password));
			System.out.println("Connection Established succesfully...");
			stat=getCnx().createStatement();

	}
	ResultSet executeStatement(String query) throws SQLException{
		return stat.executeQuery(query);
	}

	public Connection getCnx() {
		return conx;
	}

	public void setCnx(Connection conx) {
		this.conx = conx;
	}

}
