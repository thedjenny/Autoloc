package miniProjet;

import java.sql.SQLException;

public class Modify {
	cnx connect;
	int rsl;
	public boolean modifier(String name,String nom,String pr�nom ,String numt,String nump,String pass){
		try {
			connect=new cnx();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		boolean b=false;
		int i ;
		try {
		String sql="UPDATE client SET  nom='"+nom+"', prnm='"+pr�nom+"', numt='"+numt+"', nump='"+nump+"', pass='"+pass+"' WHERE userr='"+name+"'";
		rsl=connect.stat.executeUpdate(sql);
		System.out.println(rsl);
			if(rsl==1){
			b=true;
			System.out.println( " modify "+b);
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(b);
		
		return b;}
	
	public boolean upd(int mat) throws SQLException {
		connect=new cnx();
		boolean b=false;
		String sql="UPDATE vehicule SET  etat='indisponible' WHERE mat='"+mat+"'";
		int i ;
		try {
		rsl=connect.stat.executeUpdate(sql);
		System.out.println(rsl);
			if(rsl==1){
			b=true;
			System.out.println( " modify "+b);
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(b);
		return b;}
	public boolean mdfV(String mat,String mdl,String mrq ,String prx,String etat){
		try {
			connect=new cnx();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		boolean b=false;
		int i ;
		try {
		String sql="UPDATE vehicule SET  modl='"+mdl+"', marq='"+mrq+"', prix='"+prx+"', etat='"+etat+"' WHERE mat='"+mat+"';";
		rsl=connect.stat.executeUpdate(sql);
		System.out.println(rsl);
			if(rsl==1){
			b=true;
			System.out.println( " modify "+b);
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(b);
		
		return b;}
	
		public boolean mdfO(int num,String etat){
			try {
				connect=new cnx();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			boolean b=false;
		int i ;
		try {
		String sql="UPDATE offre SET  etat='"+etat+"' WHERE numoff='"+num+"'";
		rsl=connect.stat.executeUpdate(sql);
		System.out.println(rsl);
			if(rsl==1){
			b=true;
			System.out.println( " modify "+b);
			connect.getCnx().close();
		}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(b);
		
		return b;}

}
