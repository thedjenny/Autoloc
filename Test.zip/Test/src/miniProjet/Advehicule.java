package miniProjet;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.*;

public class Advehicule extends JFrame {
	JPanel p=new JPanel();
	JPanel p1=new JPanel();
	JPanel p2=new JPanel();
	JPanel p3=new JPanel();
	JPanel p4=new JPanel();
	JPanel p5=new JPanel();
	JPanel p6=new JPanel();
	JPanel p7=new JPanel();
	JPanel p8=new JPanel();
	JPanel pa=new JPanel();
	
	
	JButton louer=new JButton("Modifier");
	JButton retour=new JButton("Exit");
	JButton voiture=new JButton("Voiture");
	JButton moto=new JButton("Moto");
	JButton bus=new JButton("Bus");
	JButton camion=new JButton("Camion");
	JButton nxt=new JButton("");
	JButton bck=new JButton("");
	JButton supp=new JButton("Supprimer");
	JButton ajt=new JButton("Ajouter");
	JButton off=new JButton("Offre");
	
	JLabel mtcl=new JLabel("Matricule");
	JLabel mrq=new JLabel("          Marque: ");
	JLabel mdl=new JLabel("          Mod�le:");
	JLabel prix=new JLabel("          Prix: ");
	JLabel etat=new JLabel("          Etat: ");
	JLabel chx=new JLabel("             **** Choisissez un V�hicule :D **** ");
	ImageIcon i=new ImageIcon("C:/Users/AMINE/Desktop/images.png");
	ImageIcon i1=new ImageIcon("C:/Users/AMINE/Desktop/images2.jpg");
	ImageIcon i2=new ImageIcon("C:/Users/AMINE/Desktop/images1.jpg");
	ImageIcon i3=new ImageIcon("C:/Users/AMINE/Desktop/telechargement.jpg");
	ImageIcon i4=new ImageIcon("C:/Users/AMINE/Desktop/LOGO-LOCATION.jpg");
	JLabel ja=new JLabel(i4);
	JLabel j=new JLabel(i);
	
	JPanel conteneur=new JPanel();
	CardLayout card=new CardLayout();
	String[] lcard= {"1","2"};
	
	//fenetre modifier
	JFrame f1=new JFrame("Modifier");
	JLabel maat=new JLabel("Matricule");
	JLabel maaat=new JLabel("");
	JLabel mat=new JLabel("Etat:");
	JLabel modl=new JLabel("Model:");
	JLabel marq=new JLabel("Marque:");
	JLabel prx=new JLabel("Prix(DA):");
	JTextField tmat=new JTextField(15);
	JTextField tmdl=new JTextField(15);
	JTextField tmrq=new JTextField(15);
	JTextField tprx=new JTextField(15);
	JPanel fp=new JPanel();
	JPanel fp1=new JPanel();
	JPanel fp2=new JPanel();
	JButton bv=new JButton("Modifier");
	JButton rtr=new JButton("Retour");
	//fenetre offre
	JFrame f2 =new JFrame("Offre");
	JLabel fnumfact=new JLabel("Num�ro d'Offre");
	JLabel fetat=new JLabel("AAAAAA");
	JLabel fnom=new JLabel("type");
	JLabel fprnm=new JLabel("userr");
	JLabel fmtcl=new JLabel("matricule");
	JLabel fmrq=new JLabel(" Marque: ");
	JLabel fmdl=new JLabel(" Mod�le:");
	JLabel fprix=new JLabel(" Prix  ");
	JButton f2b=new JButton("Accepter");
	JButton f2b1=new JButton("Refuser");
	JButton f2b2=new JButton("Retour");
	JButton f2b3=new JButton("");
	JButton f2b4=new JButton("");
	JPanel f2p=new JPanel();
	JPanel f2p1=new JPanel();
	JPanel f2p2 =new JPanel();
	
	

	public Advehicule() {
		nxt.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/nxt.png"));
		bck.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/bck.png"));
		louer.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/modifier.jpg.png"));
		off.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/offre.000.jpg.png"));
		bv.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/modifier.jpg.png"));
		rtr.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/retour.jpg.png"));
		supp.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/remove.jpg.png"));
		ajt.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/add.jpg.png"));
		retour.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/exit.jpg.png"));
		nxt.setBackground(Color.WHITE);
		bck.setBackground(Color.WHITE);
		louer.setBackground(Color.WHITE);
		off.setBackground(Color.WHITE);
		bv.setBackground(Color.WHITE);
		rtr.setBackground(Color.WHITE);
		supp.setBackground(Color.WHITE);
		ajt.setBackground(Color.WHITE);
		retour.setBackground(Color.WHITE);
		voiture.setBackground(Color.WHITE);
		bus.setBackground(Color.WHITE);
		moto.setBackground(Color.WHITE);
		camion.setBackground(Color.WHITE);
		AdVaction v=new AdVaction(this);
		louer.addActionListener(v);
		retour.addActionListener(v);
		voiture.addActionListener(v);
		moto.addActionListener(v);
		bus.addActionListener(v);
		camion.addActionListener(v);
		nxt.addActionListener(v);
		bck.addActionListener(v);
		off.addActionListener(v);
		ajt.addActionListener(v);
		supp.addActionListener(v);
		bv.addActionListener(v);
		rtr.addActionListener(v);
		f2b.addActionListener(v);
		f2b1.addActionListener(v);
		f2b2.addActionListener(v);
		f2b3.addActionListener(v);
		f2b4.addActionListener(v);
		//fenetre Modifier
		f1.setSize(400, 250);
		fp.setLayout(new BorderLayout());
		fp1.setBorder(BorderFactory.createTitledBorder("Ajouter v�hicule: "));
		fp1.setLayout(new GridLayout(5, 2,00,15));
		fp1.add(maat);
		fp1.add(maaat);
		fp1.add(mat);
		fp1.add(tmat);
		fp1.add(modl);
		fp1.add(tmdl);
		fp1.add(marq);
		fp1.add(tmrq);
		fp1.add(prx);
		fp1.add(tprx);
		fp2.setBackground(Color.GRAY);
		fp2.add(bv);
		fp2.add(rtr);
		fp.add(fp1,BorderLayout.CENTER);
		fp.add(fp2, BorderLayout.SOUTH);
		f1.setContentPane(fp);
		f1.setLocationRelativeTo(null);
		//----------------------------------//
		//fenetre Offre
		f2b.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/valider.jpg.png"));
		f2b1.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/remove.jpg.png"));
		f2b2.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/retour.jpg.png"));
		f2b3.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/nxt.png"));
		f2b4.setIcon(new ImageIcon("C:/Users/AMINE/eclipse-workspace/MiniProjet/src/image/bck.png"));
		f2b.setBackground(Color.white);
		f2b1.setBackground(Color.white);
		f2b2.setBackground(Color.white);
		f2b3.setBackground(Color.white);
		f2b4.setBackground(Color.white);
		fetat.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 25));
		f2.setSize(500, 400);
		f2p1.setLayout(new GridLayout(8, 1));
		f2p1.setBorder(BorderFactory.createTitledBorder("Offre"));
		f2p.setLayout(new BorderLayout());
		f2p2.setBackground(Color.gray);
		f2p1.add(fetat);
		f2p1.add(fnumfact);
		f2p1.add(fnom);
		f2p1.add(fprnm);
		f2p1.add(fmtcl);
		f2p1.add(fmrq);
		f2p1.add(fmdl);
		f2p1.add(fprix);
		f2p2.add(f2b4);
		f2p2.add(f2b);
		f2p2.add(f2b1);
		f2p2.add(f2b2);
		f2p2.add(f2b3);
		f2p.add(f2p1,BorderLayout.CENTER);
		f2p.add(f2p2, BorderLayout.SOUTH);
		f2.getContentPane().add(f2p);
		f2.setLocationRelativeTo(null);
		
		//----------------------------------//
		setTitle("v�hicule");
		setSize(550, 300);
		
		p1.setBorder(BorderFactory.createLineBorder(Color.gray));
		p4.setBorder(BorderFactory.createLineBorder(Color.gray));
		p3.setBorder(BorderFactory.createLineBorder(Color.gray));
		p3.add(off);
		p3.add(ajt);
		p3.add(supp);
		p3.add(louer);
		p3.add(retour);
		p2.setLayout(new GridLayout(4,1,50,20));
		p2.setPreferredSize(new Dimension(100, 200));
		p2.add(voiture);
		p2.add(moto);
		p2.add(bus);
		p2.add(camion);
		p4.add(p2);
		p5.add(bck);
		p5.add(nxt);
		p7.setLayout(new GridLayout(3, 1));
		p7.add(mtcl);
		p7.add(mrq);
		p7.add(mdl);
		p7.add(etat);
		p7.add(prix);
		p8.add(j);
		p6.setLayout(new GridLayout(2, 1));
		p6.add(p8);
		p6.add(p7);
		p1.setLayout(new BorderLayout());
		p1.add(p6,BorderLayout.CENTER);
		p1.add(p5,BorderLayout.SOUTH);
		pa.setLayout(new BorderLayout());
		pa.add(ja,BorderLayout.CENTER);
		pa.add(chx, BorderLayout.SOUTH);
		conteneur.setBorder(BorderFactory.createLineBorder(Color.gray));
		conteneur.setLayout(card);
		conteneur.add(pa,lcard[0]);
		conteneur.add(p1,lcard[1]);
		p.setLayout(new BorderLayout());
		p.add(conteneur,BorderLayout.CENTER);
		p.add(p4, BorderLayout.WEST);
		p.add(p3, BorderLayout.SOUTH);
		getContentPane().add(p);
		setLocationRelativeTo(null);
		setVisible(false);
	}
	
}
