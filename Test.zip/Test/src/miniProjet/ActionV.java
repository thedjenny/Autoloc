package miniProjet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;



public class ActionV implements ActionListener {
	V�hicule v;
	Home h;
	ArrayList<auto>to;
	auto t;
	
	int indic;
	int i=1;
	autofind f=new autofind();
	public ActionV(V�hicule v) {
		this.v=v;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b=(JButton) e.getSource();
		if(b==v.retour) {
			v.setVisible(false);
			h=new Home(v.b);
			h.setVisible(true);
		}
		if(b==v.camion) {
			v.card.show(v.conteneur, v.lcard[1]);
			indic=1;
			to=f.lect("camion");
			to.clear();
			to=f.lect("camion");
			v.j.setIcon(v.i1);
			t=to.get(0);
			v.mtcl.setText("         Matricule:  "+t.matricule);
			v.mdl.setText("         Mod�le: "+t.modele);
			v.mrq.setText("         Marque:  "+t.marque);
			v.etat.setText("         Etat:  "+t.etat);
			v.prix.setText("         Prix:  "+t.prix+" DA");
		}
		if(b==v.bus) {
			v.card.show(v.conteneur, v.lcard[1]);
			indic=1;
			to=f.lect("bus");
			to.clear();
			to=f.lect("bus");
			v.j.setIcon(v.i3);
			t=to.get(0);
			v.mtcl.setText("         Matricule:  "+t.matricule);
			v.mdl.setText("         Mod�le: "+t.modele);
			v.mrq.setText("         Marque:  "+t.marque);
			v.etat.setText("         Etat:  "+t.etat);
			v.prix.setText("         Prix:  "+t.prix+" DA");
		}
		if(b==v.voiture) {
			v.card.show(v.conteneur, v.lcard[1]);
			indic=1;
			to=f.lect("voiture");
			to.clear();
			to=f.lect("voiture");
			v.j.setIcon(v.i);
			t=to.get(0);
			v.mtcl.setText("         Matricule:  "+t.matricule);
			v.mdl.setText("         Mod�le: "+t.modele);
			v.mrq.setText("         Marque:  "+t.marque);
			v.etat.setText("         Etat:  "+t.etat);
			v.prix.setText("         Prix:  "+t.prix+" DA");
		}
		if(b==v.moto) {
			v.card.show(v.conteneur, v.lcard[1]);
			indic=1;
			to=f.lect("moto");
			to.clear();
			to=f.lect("moto");
			v.j.setIcon(v.i2);
			t=to.get(0);
			v.mtcl.setText("         Matricule:  "+t.matricule);
			v.mdl.setText("         Mod�le: "+t.modele);
			v.mrq.setText("         Marque:  "+t.marque);
			v.etat.setText("         Etat:  "+t.etat);
			v.prix.setText("         Prix:  "+t.prix+" DA");
		}
		if(b==v.nxt) {
			if(indic<to.size()) {
				t=to.get(indic);
				v.mtcl.setText("         Matricule:  "+t.matricule);
				v.mdl.setText("         Mod�le: "+t.modele);
				v.mrq.setText("         Marque:  "+t.marque);
				v.etat.setText("         Etat:  "+t.etat);
				v.prix.setText("         Prix:  "+t.prix+" DA");
				indic++;
				}
				else
					JOptionPane.showMessageDialog(null, "C'est le dernier v�hicule");
		}
		if(b==v.bck) {
			if(indic>1) {
				t=to.get(indic-2);
				v.mtcl.setText("         Matricule:  "+t.matricule);
				v.mdl.setText("         Mod�le: "+t.modele);
				v.mrq.setText("         Marque:  "+t.marque);
				v.etat.setText("         Etat:  "+t.etat);
				v.prix.setText("         Prix:  "+t.prix+" DA");
				indic--; 
				
				}else
					JOptionPane.showMessageDialog(null, "C'est le dernier v�hicule");
		}
		if(b==v.louer) {
			if(v.mtcl.getText().equals("Matricule")) 
				JOptionPane.showMessageDialog(null, "Choisissez un v�hicule");
			else {
				if(t.etat.equals("indisponible"))
					JOptionPane.showMessageDialog(null, "D�soler vous pouvez pas allouer ce v�hicule il est indisponible");
				else
					v.f2.setVisible(true);
			}
				
			
			System.out.println(v.mtcl.getText());
		}
			
		if(b==v.rtr)
			v.f2.setVisible(false);
		if(b==v.plus) {
			i++;
			v.lf1.setText(""+i);
		}
		if(b==v.moin) {
			if(i>1) {
				i--;
				v.lf1.setText(""+i);
			}
		}
		if(b==v.alr) {
			Modify mm=new Modify();
			try {
				mm.upd(t.matricule);
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			Facture ff=new Facture(v.b);
			find fi=new find();
			try {
				fi.lecture(v.b);
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			add ad=new add();
			int i=Integer.parseInt(v.lf1.getText());
			int tt=t.prix*i;
			Date dd=new Date();
			Date fd=new Date();
			dd.setDate(dd.getDate()+i);
			java.sql.Date df=new java.sql.Date(dd.getYear(), dd.getMonth(), dd.getDate());
			java.sql.Date db=new java.sql.Date(fd.getYear(),fd.getMonth(),fd.getDate());
			ad.ajouterF(v.b, t.matricule, tt, db.toString(), df.toString());
			int num=fi.numfact();
			ff.numfact.setText("        - Num�ro de facture:   "+num);
			ff.nom.setText("       - nom:   "+fi.c.nom);
			ff.prnm.setText("       - pr�nom:   "+fi.c.pr�nom);
			ff.nump.setText("      - num�ro du permis:   "+fi.c.nump);
			ff.mtcl.setText("        - Matricule:   "+t.matricule);
			ff.mdl.setText("        - Mod�le:   "+t.modele);
			ff.mrq.setText("        - Marque:   "+t.marque);
			ff.prix.setText("        - Prix unitaire:   "+t.prix+" DA");
			ff.dated.setText("        - Allouer de:   "+db.toString());
			ff.datef.setText("        - Jusqu'�:   "+df.toString());
			ff.prixt.setText("        - Prix total:   "+tt+"DA");
			System.out.println(db.toString());
			System.out.println(df.toString());
			System.out.println(i);
			System.out.println(tt);
			v.setVisible(false);
			v.f2.setVisible(false);
			ff.setVisible(true);
		}
		
		
		
	}

}
