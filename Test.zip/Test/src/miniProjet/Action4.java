package miniProjet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Action4 implements ActionListener {
	Info i;
	Home h;
	public Action4(Info i) {
		this.i=i;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b=(JButton) e.getSource();
		if(b==i.b1) 
			i.card.show(i.conteneur, i.lcard[1]);
		if(b==i.b4)
			i.card.show(i.conteneur, i.lcard[0]);
		if(b==i.b3) {
			String bb=i.t2.getText();
			String c=i.t3.getText();
			String d=i.t4.getText();
			String ee=i.t5.getText();
			String pass=new String(i.pas.getPassword());
			String pass2=new String(i.pas2.getPassword());
			if(bb.equals("") ||c.equals("") ||ee.equals("") ||pass.equals("") || pass2.equals("")) 
				JOptionPane.showMessageDialog(null, "veuillez remplir tous les champs");
			else {
				if(pass.equals(pass2)) {
					Modify m=new Modify();
					if(m.modifier(i.b, bb, c, d, ee, pass)) {
						JOptionPane.showMessageDialog(null, "Vous avez bien modifier votre donn�es");
						i.setVisible(false);
						h=new Home(i.b);
						h.setVisible(true);
					}else
						JOptionPane.showMessageDialog(null, "Erreur");
					
				}else
					JOptionPane.showMessageDialog(null, "Confirmer votre mot de passe");
			}
				
		}
		if(b==i.b2){
			i.setVisible(false);
			h=new Home(i.b);
			h.setVisible(true);
		}
		
		
	}

}
