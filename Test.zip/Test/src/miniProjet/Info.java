package miniProjet;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.sql.SQLException;

import javax.swing.*;

public class Info extends JFrame {
	String b;
	JLabel l=new JLabel("    nom du compte: ");
	JLabel l1=new JLabel("    Mot de pass: ");
	JLabel l2=new JLabel("    nom: ");
	JLabel l3=new JLabel("    pr�nom: ");
	JLabel l4=new JLabel("    num�ro du permis: ");
	JLabel l5=new JLabel("    num�ro du t�l�phone: ");
	JButton b1=new JButton("Modifier");
	JButton b2=new JButton("Retour");
	JButton b3=new JButton("Enregistrer");
	JButton b4=new JButton("annuler");
	JPanel p=new JPanel();
	JPanel p1=new JPanel();
	JPanel p2=new JPanel();
	JPanel p3=new JPanel();
	JPanel p4=new JPanel();
	JPanel p5=new JPanel();
	JPanel p6=new JPanel();
	JLabel nom=new JLabel("Nom: "),
			prnm=new JLabel("Pr�nom: "),
			num=new JLabel("Num�ro du t�l�phone: "),
			permis=new JLabel("Num�ro du permis: "),
			pass=new JLabel("Mot de passe: "),
			pass2=new JLabel("Confirmer mot de passe: ");
	JTextField 	t2=new JTextField(15),
			t3=new JTextField(15),
			t4=new JTextField(15),
			t5=new JTextField(15);
	JPasswordField pas=new JPasswordField(),
			pas2=new JPasswordField();
	JPanel conteneur=new JPanel();
	CardLayout card=new CardLayout();
	String[] lcard= {"1","2"};
	
	public Info(String b) {
		b1.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/modifier.jpg.png"));
		b2.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/retour.jpg.png"));
		b3.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/MD.disc.3.5.jpg.png"));
		b4.setIcon(new ImageIcon("C:/Users/SEGHIRI TAKI EDDINE/Desktop/src/Test/src/image/retour.jpg.png"));
		this.b=b;
		find f=new find();
		try {
			f.lecture(b);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		l.setText("    nom du compte: "+f.c.name);
		l1.setText("    Mot de pass: "+f.c.pass);
		l2.setText("    nom: "+f.c.nom);
		l3.setText("    pr�nom: "+f.c.pr�nom);
		l4.setText("    num�ro du permis: "+f.c.nump);
		l5.setText("    num�ro du t�l�phone: "+f.c.numt);
		t2.setText(f.c.nom);
		t3.setText(f.c.pr�nom);
		t4.setText(f.c.numt);
		t5.setText(f.c.nump);
		pas.setText(f.c.pass);
		pas2.setText(f.c.pass);
		Action4 a=new Action4(this);
		b1.addActionListener(a);
		b2.addActionListener(a);
		b3.addActionListener(a);
		b4.addActionListener(a);
		
		setTitle("Information");
		setSize(400, 300);
		setTitle("Inscription");
		setSize(400, 300);
		
		p1.setLayout(new GridLayout(6, 1));
		p1.add(nom);
		p1.add(prnm);
		p1.add(num);
		p1.add(permis);
		p1.add(pass);
		p1.add(pass2);
		
		p2.setLayout(new GridLayout(6, 1));
		p2.add(t2);
		p2.add(t3);
		p2.add(t4);
		p2.add(t5);
		p2.add(pas);
		p2.add(pas2);
		
		p3.add(b3);
		p3.add(b4);
		
		p.setBorder(BorderFactory.createTitledBorder("Param�tres g�n�raux du compte"));
		p.setLayout(new BorderLayout());
		p.add(p1,BorderLayout.WEST);
		p.add(p2,BorderLayout.CENTER);
		p.add(p3, BorderLayout.SOUTH);
		
		p6.setBorder(BorderFactory.createTitledBorder("Param�tres g�n�raux du compte"));
		p6.setLayout(new GridLayout(6, 1));
		p6.add(l);
		p6.add(l1);
		p6.add(l2);
		p6.add(l3);
		p6.add(l4);
		p6.add(l5);
		
		p4.setBackground(Color.GRAY);
		p4.add(b1);
		p4.add(b2);
		
		conteneur.setLayout(card);
		conteneur.add(p6,lcard[0]);
		conteneur.add(p,lcard[1]);
		
		p5.setLayout(new BorderLayout());
		p5.add(conteneur,BorderLayout.CENTER);
		p5.add(p4, BorderLayout.SOUTH);
		
		getContentPane().add(p5);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
}