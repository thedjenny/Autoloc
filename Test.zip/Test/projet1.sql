-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 05 fév. 2022 à 21:46
-- Version du serveur :  10.4.19-MariaDB
-- Version de PHP : 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet1`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `userr` varchar(20) NOT NULL,
  `nom` varchar(20) DEFAULT NULL,
  `prnm` varchar(20) DEFAULT NULL,
  `numt` varchar(20) DEFAULT NULL,
  `nump` varchar(20) DEFAULT NULL,
  `pass` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

CREATE TABLE `facture` (
  `numfact` int(11) NOT NULL,
  `datedeb` varchar(20) DEFAULT NULL,
  `datefin` varchar(20) DEFAULT NULL,
  `userr` varchar(20) DEFAULT NULL,
  `mat` varchar(25) DEFAULT NULL,
  `total` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `offre`
--

CREATE TABLE `offre` (
  `numoff` int(11) NOT NULL,
  `typ` varchar(20) DEFAULT NULL,
  `mat` int(11) DEFAULT NULL,
  `mdl` varchar(20) DEFAULT NULL,
  `mrq` varchar(20) DEFAULT NULL,
  `prx` int(11) DEFAULT NULL,
  `userr` varchar(20) DEFAULT NULL,
  `etat` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `vehicule`
--

CREATE TABLE `vehicule` (
  `mat` varchar(25) NOT NULL,
  `typ` varchar(25) DEFAULT NULL,
  `modl` varchar(25) DEFAULT NULL,
  `marq` varchar(25) DEFAULT NULL,
  `prix` double DEFAULT NULL,
  `etat` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`userr`);

--
-- Index pour la table `facture`
--
ALTER TABLE `facture`
  ADD PRIMARY KEY (`numfact`),
  ADD KEY `mat_fk` (`mat`),
  ADD KEY `userr_fk` (`userr`);

--
-- Index pour la table `offre`
--
ALTER TABLE `offre`
  ADD PRIMARY KEY (`numoff`),
  ADD KEY `userr` (`userr`);

--
-- Index pour la table `vehicule`
--
ALTER TABLE `vehicule`
  ADD PRIMARY KEY (`mat`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `facture`
--
ALTER TABLE `facture`
  MODIFY `numfact` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `offre`
--
ALTER TABLE `offre`
  MODIFY `numoff` int(11) NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `facture`
--
ALTER TABLE `facture`
  ADD CONSTRAINT `mat_fk` FOREIGN KEY (`mat`) REFERENCES `vehicule` (`mat`),
  ADD CONSTRAINT `userr_fk` FOREIGN KEY (`userr`) REFERENCES `client` (`userr`);

--
-- Contraintes pour la table `offre`
--
ALTER TABLE `offre`
  ADD CONSTRAINT `userr` FOREIGN KEY (`userr`) REFERENCES `client` (`userr`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
